# polls
Log in with your name and vote on polls or create one of your own! Application using Angular, Express, MongoDB and Node
